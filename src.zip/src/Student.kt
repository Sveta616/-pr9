open class Student(var name:String, var surname:String, var otch:String, var pol:String, var gr:String, var data:String, var rost:Double, var ves:Double, var sport:String)
{
    open fun SetInfo()
    {
        try {
            println("Введите имя")
            name= readLine()!!.toString()
            println("Введите фамилию")
            surname= readLine()!!.toString()
            println("Введите отчество")
            otch= readLine()!!.toString()
            println("Введите пол студента")
            pol= readLine()!!.toString()
            println("Введите дату рождения")
            data= readLine()!!.toString()
            println("Введите группу")
            gr= readLine()!!.toString()
            do {
                println("Введите рост")
                rost = readLine()!!.toDouble()
            }while(rost>=200||rost<=120)
            do {
                println("Введите вес")
                ves = readLine()!!.toDouble()
            }while(ves<=30)
            println("Введите вид спорта, которым вы занимаетесь")
            sport= readLine()!!.toString()

        } catch(e:Exception)
        {
            println("Введите данные корректно")
        }
    }
    open fun GetInfo()
    {
        println("$name\n$surname\n$otch\n$pol\nГруппа студента:$gr\nВес:$ves\nРост:$rost\nДата рождения:$data\nВид спорта, которым занимется:$sport")
    }
    open fun Vozr()
    {
        println("Введите свой год рождения")
        var g= readLine()!!.toInt()
        var age:Double
        age=2024.00-g.toDouble()
        println("Возраст:$age")
    }
}
class Platnik(val money:Int, var studying:String, pname:String, psurname:String, potch:String, ppol:String, pgr:String,pdata:String, prost:Double, pves:Double, psport:String):Student(pname,psurname,potch,ppol,pgr,pdata,prost,pves,psport)
{
    override fun GetInfo()
    {
        println("$name\n$surname\n$otch")
    }

    fun Studi()
    {
        do
        {
            println("Какая у вас форма обучения(Введите Платная или Бесплатная или Заочная )")
            studying= readLine()!!.toString()

        }while(studying!="Платная"&& studying!="Бесплатная"&& studying!="Заочная")
    }
    fun Money()
    {
        when
        {
            (studying=="Платная")->println("Ваше обучение платное => вы платите $money")
        }
    }
    fun Vozmoznost()
    {
        if (studying=="Бесплатная")
        {
            println("Ваша форма обучения бесплатная=>вы не платите за учёбу")
        }
        else if(studying=="Заочная")
        {
            println("Вы учитесь заочно=>вам уже присвоена скидка")
        }
        else {
            var at: Double
            do {
                println("Введите ваш балл аттестата")
                at = readLine()!!.toDouble()
            } while (at < 2 || at > 6)
            if (at > 4) {
                println("У вас есть возможность поступить на бюджет с таким баллом при сдачи сессии на 4-5")
            }else println("У вас маловероятный шанс попасть на бюджет с таким баллом")
        }

    }
}
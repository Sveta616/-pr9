fun main()
{
    var av=Avtomobil("", 0.0,0.0)
    av.SetInf()
    av.GetInf()
    av.InfProd()
    //BMW
    var bm=BMW(0.6,"","BMW",av.marka,av.moshnost,av.price)
    bm.Inf()
    bm.GetInf()
    bm.Skidka()
    bm.Colour()
    //Nissan
    var ns=Nissan("",0.0,"","Nissan",av.marka,av.moshnost,av.price)
    ns.Infor()
    ns.VideCos()
    ns.Time()

}

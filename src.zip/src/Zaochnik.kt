class Zaochnik(val k:Double, var study:String, mname:String, msurname:String, motch:String, mpol:String, mgr:String,mdata:String, mrost:Double, mves:Double, msport:String):Student(mname,msurname,motch,mpol,mgr,mdata,mrost,mves,msport)
{
    override fun GetInfo()
    {
        println("$name\n$surname\n$otch")
    }

  fun Stud()
    {
        println("Какая у вас форма обучения(Введите Очная или Заочная)")
        study= readLine()!!.toString()
        when
        {
            (study!="Очная"&& study!="Заочная")->println("Введите правильно форму вашего обучения")
        }
    }

    fun Price()
    {
        var k1=45000*k
        when
        {
            (study=="Заочная")->println("Вы платите $k1")
            else-> println("Ваша форма обучения очная")
        }

    }
}
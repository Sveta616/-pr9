class Nissan(vid:String,coust:Double,vr:String,var na:String,nmarka:String,nmoshnost:Double,nprice:Double):Avtomobil(nmarka,nmoshnost,nprice)
{
    fun Infor()
    {
        println("Марка автомобиля:$na")
    }
    override fun GetInf()
    {
        println("Мощность:$moshnost\nЦена:$price")
    }

    fun VideCos() {
        var vid: String
        do {
            println("Введите вид машины(Семейная или Легковая)")
            vid = readLine()!!.toString()
        } while (vid != "Семейная" && vid != "Легковая")
        if(vid=="Семейная")
        {
           var coust=price+2000
            println("У вас семейная машина=>ваша цена дороже $coust")
        }
        else println("Цена вашего автомобиля=$price")
    }

fun Time()
{
    var vr:String
    do {
        println("Введите в какое время вам удобно встретиться(салон работает с 8.00 до 20.00,используйте точку)")
        vr= readLine()!!.toString()
    }while(vr.toDouble()>=8.00&&vr.toDouble()<=20.00)
    println("Время встречи:$vr")
}



}

class BMW(var st:Double,var c:String,var nam:String,bmarka:String,bmoshnost:Double,bprice:Double):Avtomobil(bmarka,bmoshnost,bprice)
{
   fun Inf()
   {
       println("Марка автомобиля:$nam")
   }
    override fun GetInf()
    {
        println("Мощность:$moshnost\nЦена:$price")
    }
    fun Skidka()
    {
       var st= price*0.6
        println("На BMW идёт скидка, стоимость=$st")
    }
    fun Colour()
    {
        try {
            println("Введите цвет автомобиля")
            c = readLine()!!.toString()
            println("Цвет вашего автомобиля:$c")
        }catch(e:Exception)
        {
            println("Введите данные корректно")
        }

    }
}
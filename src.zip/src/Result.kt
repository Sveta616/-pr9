
    fun main() {
        var st =Student( "",  "",  "",  "",  "",  "",  0.0,  0.0,  "")
        st.SetInfo()
        st.GetInfo()
        st.Vozr()
        var zao=Zaochnik(0.6,"",st.name,st.surname,st.otch,"","","",0.0,0.0,"")
        //Заочник
        zao.GetInfo()
        zao.Stud()
        zao.Price()
        //Платник
        var pl=Platnik(45000, "",st.name,st.surname,st.otch,"","","",0.0,0.0,"" )
        pl.GetInfo()
        pl.Studi()
        pl.Money()
        pl.Vozmoznost()
    }

open class Avtomobil(var marka:String,var moshnost:Double,var price:Double)
{
    open fun SetInf()
    {
        try {
            println("Введите марку автомобиля")
            marka= readLine()!!.toString()
            do {
                println("Введите мощность автомобиля")
                moshnost= readLine()!!.toDouble()
            }while(moshnost<=0)
            do {
                println("Введите цену автомобиля")
                price = readLine()!!.toDouble()
            }while(price<=0)
        }catch(e:Exception)
        {
            println("Введите данные корректно")
        }
    }
    open fun GetInf()
    {
        println("Марка автомобиля:$marka\nМощность:$moshnost\nЦена:$price")
    }
    open fun InfProd()
    {
        println("Информация о продавце:")
        var fio:String
        fio="Михайлов Олег Викторович"
        var number:String
        number="+79120324957"
        println("$fio\n$number")
    }

}